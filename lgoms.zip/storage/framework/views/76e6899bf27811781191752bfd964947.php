
<?php if($message = Session::get('success')): ?>

<div class="alert alert-info">
<?php echo e($message); ?>

</div>

<?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/navbarstyle.css" >
    <link rel="stylesheet" href="css/loginpagestyle.css" >
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"> -->

    <style>
        
    </style>
</head>
<body>
  <div class="smaller_body">
<div class="bg">
  <img src="images/bg.jpg" alt="">
</div>

        <div class="menu-container">
            <div class="menu">
            
                <div class="marking" style="color:#FFFFFF">.</div>

                <div class="logo"><img src="images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

                <div class="marking" style="color:#FFFFFF">.</div>
            
            </div>
        </div>

<div class="wrapper_big">
        <div class="wrapper">
            <div class="form-box login">
                <img src="images/profile_picture_default.png" alt="profile pic" style="width:90px;height:90px;">
                <form action="<?php echo e(route('user.validate_login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-box">
                        <span class="icon"><ion-icon name="mail"></ion-icon></span>
                        <input type="email" placeholder="Email" style="background-color: #FF6161;">
                        <?php if($errors->has('email')): ?>
							<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
						<?php endif; ?>
                        <label hidden>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                        <input type="password" placeholder="Password" style="background-color: #FF6161;">
                        <?php if($errors->has('password')): ?>
							<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
						<?php endif; ?>
                        <label hidden>Password</label>
                    </div>
                    <div class="remember-forgot">
                        <label><input type="checkbox">Remember me</label>
                        <a href="#">Forgot password?</a>
                    </div>
                    <div><button type="submit" class="btn">Login</button></div>
                    
                </form>
            </div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
    
    </div>
    </div>
</div>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/loginPage.blade.php ENDPATH**/ ?>