<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>