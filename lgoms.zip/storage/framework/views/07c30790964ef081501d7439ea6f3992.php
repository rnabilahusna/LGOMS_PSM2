<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Design Details</title>
    <link rel="stylesheet" href="/css/mydesignsliststyle.css" >
    <link rel="stylesheet" href="/css/navbarstyle.css" >
    <link rel="stylesheet" href="/css/qcdesigndetailspagestyle.css" >
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<div class="menu-container">
    <div class="menu">
        <div class="logo"><img src="/images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

        <div class="links">
        <div class="home"><a href="<?php echo e(route('store.mainWindow')); ?>" style="color:black; text-decoration:none">Home</a></div>
            <div class="order_list"><a href="<?php echo e(route('store.ordersListPage')); ?>" style="color:black; text-decoration:none">Order List</a></div>
            <div class="design_list"><a href="<?php echo e(route('store.designsListPage')); ?>" style="color:black; text-decoration:none">Design List</a></div>
        </div>


        <?php if(auth()->guard()->check()): ?>
       
        <div class="dropdown">
            <div class="profile-group">
                <div class="profile-pic"><img  src="/images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
                <div class="profile"><p class="dropbtn"><?php echo e(auth()->user()->name); ?></p></div>
            </div>

            <div class="dropdown-content">
                <a href="logout">Sign Out</a>
            </div>


        </div>

        <?php endif; ?>
        
    </div>
</div>

    <?php if($message = Session::get('success')): ?>

	<div class="alert alert-success">
		<?php echo e($message); ?>

	</div>

	<?php endif; ?>

    <div class="card">

		<div class="cardheader">
			<div class="row">
				<div class="col col-md-6" id="thetitle"><b>Part No: <?php echo e($design->partNo); ?></b></div>
				
				<a href="<?php echo e(route('store.designsListPage')); ?>" class="btn btn-primary btn-sm float-end" id="requestbutton" style="width:90px">
                <i class="fa fa-arrow-circle-left" style="font-size:25px;color:white"></i>
                </a>
			</div>
			</div>
		</div>

    
        <div class="cardbody_qc">

        <div class="left">
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form"></label>
                <div class="col-sm-10">
                    <img class="partDesignImage" src="<?php echo e(asset('images/' . $design->partDesign)); ?>" width="275" />
                </div>
            </div>


            <div class="updateQuantityForm">
			<form method="post" action="<?php echo e(route('design.updateGoodsStock', $design->designID)); ?>" enctype="multipart/form-data">
			
                <?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
			
				<label>Update the quantity:</label>
                <span class="input-group-addon"></span>
                    <input  name="goodsStock" placeholder="<?php echo e($design->goodsStock); ?> " class="form-control"  type="text" value="<?php echo e(old('goodsStock')); ?>">
                    <?php if($errors->has('goodsStock')): ?>
                        <span class="text-danger" style="color:red"><?php echo e($errors->first('goodsStock')); ?></span>
                    <?php endif; ?>
                </span>
                  
                <div class="text-center">
				    <input type="hidden" name="hidden_id" value="<?php echo e($design->designID); ?>" />
				    <input type="submit" class="btn btn-primary" value="Edit" id="requestbutton"/>
			    </div>
			</form>
            </div>
        </div>
            

        <div class="right">

             <div class="detailstop" id="partNo">
                <label>Part No: </label>
					<?php echo e($design->partNo); ?>

            </div>
            <div class="details" id="partDescription">
                <label>Part Description: </label>
					<?php echo e($design->partDescription); ?>

            </div>
			<div class="details" id="goodsStock">
                <label>Quantity currently in stock: </label>
					<?php echo e($design->goodsStock); ?>

            </div>

            <div class="details" id="unitPrice">
                <label>Unit Price:</label>
					<?php echo e($design->unitPrice); ?>

            </div>

            <div class="details" id="noOfCavities">
                <label>No of cavities: </label>
					<?php echo e($design->noOfCavities); ?>

            </div>

            <div class="details" id="noOfEnvelope">
                <label>No of envelope:</label>
					<?php echo e($design->noOfEnvelope); ?>

            </div>

            <div class="details" id="noOfSheets">
                <label>No of sheets:</label>
					<?php echo e($design->noOfSheets); ?>

            </div>

    
        </div>
            
			
        </div>


	</div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/store/designDetailsPage.blade.php ENDPATH**/ ?>