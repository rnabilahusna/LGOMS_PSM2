<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Purchase Order</title>
    <link rel="stylesheet" href="/css/navbarstyle.css" >
    <link rel="stylesheet" href="/css/updateJO.css" >
    <!-- <link rel="stylesheet" href="/css/designdetailspagestyle.css" > -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/mydesignsliststyle.css" >
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="menu-container">
    <div class="menu">
        <div class="logo"><img src="/images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

        <div class="links">
        <div class="home"><a href="<?php echo e(route('client.mainWindow')); ?>" style="color:black; text-decoration:none">Home</a></div>
            <div class="my_designs"><a href="<?php echo e(route('client.myDesignsListPage')); ?>" style="color:black; text-decoration:none">My Designs</a></div>
            <div class="my_orders"><a href="<?php echo e(route('client.myOrdersListPage')); ?>" style="color:black; text-decoration:none">My Orders</a></div>
        </div>

        <?php if(auth()->guard()->check()): ?>
       
        <div class="dropdown">
            <div class="profile-group">
                <div class="profile-pic"><img  src="/images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
                <div class="profile"><p class="dropbtn"><?php echo e(auth()->user()->name); ?></p></div>
            </div>

            <div class="dropdown-content">
                <a href="logout">Sign Out</a>
            </div>


        </div>

        
       
    </div>
</div>

    <?php if($message = Session::get('success')): ?>

	<div class="alert alert-success">
		<?php echo e($message); ?>

	</div>

	<?php endif; ?>

<div class="card">

		<div class="cardheader">
			<div class="row">
				<div class="col col-md-6" id="thetitle"><b>Purchase Order </b></div>
				    <a href="<?php echo e(route('design.showForClient', $design->designID)); ?>" style="width:90px" class="btn btn-success btn-sm float-end" id="requestbutton">
                        <i class="fa fa-arrow-circle-left" style="font-size:25px;color:white"></i>
                    </a>
			    </div>
			</div>
		</div>

	
		<div class="cardbody" id="cardbody">

        <form method="post" action="<?php echo e(route('order.submitOrder')); ?>" enctype="multipart/form-data">
					
					<?php echo csrf_field(); ?>
					<?php echo method_field('POST'); ?>

        <hr>
        <!-- FIRST ROW -->
        <div class="firstbigrow">
            <div class="leftonly firstrow">
                
                <div class="input-group details"> Buyer Code / Abbrevation:&nbsp&nbsp&nbsp&nbsp
                    <input  name="buyerCode" value="<?php echo e($design->getClient->buyerCode); ?> " class="form-control"  type="text" readonly>
                </div>
                <div class="input-group details"> Buyer Name:&nbsp&nbsp&nbsp&nbsp
                    <input  name="buyerName" value="<?php echo e($design->getClient->buyerName); ?> " class="form-control"  type="text" readonly>
                </div>
                <div class="input-group details"> Buyer Address:&nbsp&nbsp&nbsp&nbsp
                    <input  name="buyerAddress" value="<?php echo e($design->getClient->buyerAddress); ?> " class="form-control"  type="text" readonly>
                </div>
                <div class="input-group details"> Buyer Section Code / Name:&nbsp&nbsp&nbsp&nbsp
                    <input  name="buyerSectionCodeOrName" value="<?php echo e($design->getClient->buyerSectionCodeOrName); ?> " class="form-control"  type="text" readonly>
                </div>
                

            </div>
            
            <div class="rightonly firstrow">
                <div class="input-group details"> Buyer Correspondent / Name:&nbsp&nbsp&nbsp&nbsp
                    <input  name="buyerCorrespondentOrName" value="<?php echo e($design->getClient->buyerCorrespondentOrName); ?> " class="form-control"  type="text" readonly>
                </div>
                <div class="input-group details"> Authorization Code / Name:&nbsp&nbsp&nbsp&nbsp
                    <input  name="authorizationCodeOrName" value="<?php echo e($design->getClient->authorizationCodeOrName); ?> " class="form-control"  type="text" readonly>
                </div>
                <div class="input-group details"> Contact No:&nbsp&nbsp&nbsp&nbsp
                    <input  name="contactNum" value="<?php echo e(auth()->user()->contactNum); ?> " class="form-control"  type="text" readonly>
                </div>
                <div class="input-group details"> Email:&nbsp&nbsp&nbsp&nbsp
                    <input  name="email" value="<?php echo e(auth()->user()->email); ?> " class="form-control"  type="email" readonly>
                </div>

            </div>
        </div>

        <hr>
        <!-- SECOND ROW -->
        <div class="secondbigrow">
            <div class="leftonly secondrow">

                <div class="input-group details"> P/O No:&nbsp&nbsp&nbsp&nbsp
                    <input  name="PONo" value="<?php echo e(old('PONo')); ?> " class="form-control"  type="text">
                </div>
                <div class="input-group details"> Creation Date:*&nbsp&nbsp&nbsp&nbsp
                    <input  name="creationDate" value="<?php echo e(old('creationDate')); ?> " class="form-control"  type="date" required>
                </div>
                <div class="input-group details"> Quotation No:&nbsp&nbsp&nbsp&nbsp
                    <input  name="QuotationNo" value="<?php echo e(old('QuotationNo')); ?> " class="form-control"  type="text">
                </div>
            </div>

            <div class="rightonly secondrow">
                <div class="input-group details"> Order Status:&nbsp&nbsp&nbsp&nbsp
                    <input  name="orderStatus" value="NEW" class="form-control"  type="text" readonly>
                </div>
                <div class="input-group details"> Issued Date:*&nbsp&nbsp&nbsp&nbsp
                    <input  name="IssuedDate" value="<?php echo e(old('IssuedDate')); ?> " class="form-control"  type="date" required>
                </div>
               
            </div>
        
        </div>

        <hr>
        <!-- THIRD ROW -->
        <div class="thirdbigrow">
            <div class="leftonly thirdrow">

                <div class="input-group details"> Shipping Term:&nbsp&nbsp&nbsp&nbsp
                    <input  name="shippingTerm" value="<?php echo e(old('shippingTerm')); ?> " class="form-control"  type="text">
                </div>
                <div class="input-group details"> Payment Term:&nbsp&nbsp&nbsp&nbsp
                    <input  name="paymentTerm" value="<?php echo e(old('paymentTerm')); ?> " class="form-control"  type="text">
                </div>
                <div class="input-group details"> Term Of Payment:&nbsp&nbsp&nbsp&nbsp
                    <input  name="termOfPayment" value="<?php echo e(old('termOfPayment')); ?> " class="form-control"  type="text">
                </div>
                <div class="input-group details"> Comment:&nbsp&nbsp&nbsp&nbsp
                    <input  name="comment" value="<?php echo e(old('comment')); ?> " class="form-control"  type="textarea">
                </div>
            </div>

            <div class="rightonly thirdrow">
                <div class="input-group details"> Currency Code:&nbsp&nbsp&nbsp&nbsp
                    <input  name="currencyCode" value="<?php echo e(old('currencyCode')); ?> " class="form-control"  type="text">
                </div>
                <div class="input-group details"> Shipping Mode:&nbsp&nbsp&nbsp&nbsp
                    <input  name="shippingMode" value="<?php echo e(old('shippingMode')); ?> " class="form-control"  type="text">
                </div>
                <div class="input-group details"> Remark:&nbsp&nbsp&nbsp&nbsp
                    <input  name="remark" value="<?php echo e(old('remark')); ?> " class="form-control"  type="textarea">
                </div>
                <div class="input-group details"> Place Of Delivery:&nbsp&nbsp&nbsp&nbsp
                    <input  name="placeOfDelivery" value="<?php echo e(old('placeOfDelivery')); ?> " class="form-control"  type="text">
                </div>
            </div>
        
        </div>


        <hr>
        <!-- FOURTH ROW -->
        <div class="fourthbigrow">
        <table>
            <tr>
                <th class="column colone">Line No</th>
                <th class="column coltwo">Action Code</th>
                <th class="column colthree" style="width:10%">Part No*</th>
                <th class="column colfour">Part Description*</th>
                <th class="column colfive">Sales Unit Price Basis (UOM)</th>
                <th class="column colsix">Quantity Per Package (UOM)*</th>
                <th class="column colseven">Unit Price</th>
                <th class="column coleight">Quantity*</th>
                <th class="column colnine">UOM</th>
                <th class="column colten">Reference Data / ETD</th>
                <th class="column coleleven">Delivery Date / ETA*</th>
                <th class="column coltwelve">Amount</th>
                <th class="column colonethree">R/O No</th>
            </tr>
            <tr>
                <td><input  name="lineNo" placeholder="Line No" class="form-control"  type="number" value="<?php echo e(old('lineNo')); ?>"></td>
                <td><input  name="actionCode" placeholder="Action Code*" class="form-control"  type="text" value="NEW" readonly></td>
                <td><input  name="partNo" placeholder="Part No" class="form-control"  type="text" value="<?php echo e($design->partNo); ?>" readonly></td>
                <td><input  name="partDescription" placeholder="Part Description" class="form-control"  type="text" value="<?php echo e($design->partDescription); ?>" readonly></td>
                <td><input  name="salesUnitPriceBasisUOM" placeholder="Sales Unit Price Basis (UOM)" class="form-control"  type="number" value="<?php echo e(old('salesUnitPriceBasisUOM')); ?>"></td>
                <td><input  name="quantityPerPackageUOM" placeholder="Quantity Per Package (UOM)" class="form-control"  type="number" value="<?php echo e(old('quantityPerPackageUOM')); ?>" required></td>
                <td><input  name="unitPrice" placeholder="Unit Price (RM)" class="form-control"  type="number" step="0.01" value="<?php echo e($design->unitPrice); ?>" readonly></td>
                <td><input  name="quantity" placeholder="Quantity" class="form-control"  type="number" value="<?php echo e(old('quantity')); ?>" Required></td>
                <td><input  name="UOM" placeholder="UOM" class="form-control"  type="text" value="<?php echo e(old('UOM')); ?>"></td>
                <td><input  name="referenceDateETD" placeholder="Reference Data / ETD" class="form-control"  type="date" value="<?php echo e(old('referenceDateETD')); ?>"></td>
                <td><input  name="deliveryDateETA" placeholder="Delivery Date / ETA" class="form-control"  type="date" value="<?php echo e(old('deliveryDateETA')); ?>" required></td>
                <td><input  name="amount" placeholder="Amount" class="form-control"  type="number" value="<?php echo e(old('amount')); ?>"></td>
                <td><input  name="RONo" placeholder="R/O No" class="form-control"  type="number" value="<?php echo e(old('RONo')); ?>"></td>
            </tr>
        </table>
        </div>

        <div class="text-center">
            <input type="hidden" name="paymentStatus" value="PENDING" />          
            <input type="hidden" name="designID" value="<?php echo e($design->designID); ?>" />
            <input type="hidden" name="goodsStock" value="<?php echo e($design->goodsStock); ?>" />
            <input type="hidden" name="hidden_id" value="<?php echo e($design->designID); ?>" />

            <br>
            <input type="submit" class="btn btn-primary float-end" id="requestbutton" value="Submit Order" />
		<br><br>
        </div>



</form>
        </div>
        

</div>
<?php endif; ?> 

</body>
</html><?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/client/makeOrderPage.blade.php ENDPATH**/ ?>