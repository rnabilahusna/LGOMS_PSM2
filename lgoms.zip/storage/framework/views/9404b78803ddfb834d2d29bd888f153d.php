<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="/css/mydesignsliststyle.css" >
	<link rel="stylesheet" href="/css/orderdetailspagestyle.css" >
    <link rel="stylesheet" href="/css/navbarstyle.css" >
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>My Orders Details Page</title>
</head>
<body>
<div class="menu-container">
		<div class="menu">
			<div class="logo"><img src="/images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

			<div class="links">
            <div class="home"><a href="<?php echo e(route('client.mainWindow')); ?>" style="color:black; text-decoration:none">Home</a></div>
                <div class="my_designs"><a href="<?php echo e(route('client.myDesignsListPage')); ?>" style="color:black; text-decoration:none">My Designs</a></div>
				<div class="my_orders"><a href="<?php echo e(route('client.myOrdersListPage')); ?>" style="color:black; text-decoration:none">My Orders</a></div>
			</div>

			<?php if(auth()->guard()->check()): ?>
       
			<div class="dropdown">
				<div class="profile-group">
					<div class="profile-pic"><img  src="/images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
					<div class="profile"><p class="dropbtn"><?php echo e(auth()->user()->name); ?></p></div>
				</div>

				<div class="dropdown-content">
					<a href="logout">Sign Out</a>
				</div>


			</div>

			<?php endif; ?>
			
		</div>
	</div>

	<?php if($message = Session::get('success')): ?>

	<div class="alert alert-success">
		<?php echo e($message); ?>

	</div>

	<?php endif; ?>

	<div class="card">

		<div class="cardheader">
			<div class="row">
				<div class="col col-md-6" id="thetitle"><b>My Order</b></div>
					<a href="<?php echo e(route('client.myOrdersListPage')); ?>" style="width:90px"  class="btn btn-primary btn-sm float-end" id="requestbutton">
						<i class="fa fa-arrow-circle-left" style="font-size:25px;color:white"></i>
					</a>
					<a href="<?php echo e(route('order.viewInvoice',$order->id)); ?>" target="_blank" style="width:250px"  class="btn btn-primary btn-sm float-end" id="requestbutton">View Invoice</a>
					<a href="<?php echo e(route('order.downloadInvoice',$order->id)); ?>" style="width:250px"  class="btn btn-primary btn-sm float-end" id="requestbutton">
						<i class="fa fa-download" style="font-size:20px;color:white"></i>&nbsp Download Invoice
					</a>
					
			</div>
			</div>
		</div>

	
		<div class="cardbody">

			<div class="leftinfo">
				<div class="partDesign"><img class="partDesignImage" src="<?php echo e(asset('images/' . $order->getDesign->partDesign)); ?>" width="275" /></div>

				<div class="paymentStatus">
					<label>PAYMENT PROOF:&nbsp&nbsp</label>
						<?php echo e($order->paymentStatus); ?>

				</div>
				
				<?php if($order->paymentStatus == 'SUBMITTED' || $order->paymentStatus == 'PAYMENT REJECTED' || $order->paymentStatus == 'PENDING'): ?>
				<form method="post" action="<?php echo e(route('order.updatePaymentInfo', $order->id)); ?>" enctype="multipart/form-data">
					
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
					
                    <div class="newPaymentProof">
                            <label>Payment proof:&nbsp&nbsp</label>
                                <input type="file" name="paymentProof" />
                        </div>

					<div class="text-center buttonsubmit">
						<input type="hidden" class="submitbutton" name="paymentStatus" value="SUBMITTED" />
						<input type="hidden" name="hidden_id" value="<?php echo e($order->id); ?>" />
						<input type="submit" class="btn btn-primary btn-sm float-end" id="requestbutton" value="Submit payment proof" />
			    	</div>
				</form>
				<?php else: ?>
				<?php endif; ?>

				<?php if($order->paymentStatus == 'SUBMITTED' || $order->paymentStatus == 'PAYMENT REJECTED'): ?>
				
				<img src="<?php echo e(asset('images/' . $order->paymentProof)); ?>" width="155" style="padding-top:25px" />
				<a href="<?php echo e(route('client.viewPaymentProof', $order->id)); ?>" target="_blank">View payment proof</a>
				
				<?php endif; ?>
			</div>

			<div class="centerinfo">
				<div class="partNo">
					<label><b>PART NO.:&nbsp</label>
						<?php echo e($order->partNo); ?></b>
				</div>
            	
				
				<div class="partName">
					<label>PART NAME:&nbsp</label>
						<?php echo e($order->getDesign->partDescription); ?>

				</div>

				<div class="ordeStatus">
					<label>Order Status:&nbsp</label>
						<?php echo e($order->orderStatus); ?>

				</div>
				<div class="currencyCode">
					<label>Currency Code:&nbsp</label>
						<?php echo e($order->currencyCode); ?>

				</div>
				<div class="shippingMode">
					<label>Shipping Mode:&nbsp</label>
						<?php echo e($order->shippingMode); ?>

				</div>
				<div class="placeOfDelivery">
					<label>Place of Delivery:&nbsp</label>
						<?php echo e($order->placeofDelivery); ?>

				</div>
				<div class="shippingTerm">
					<label>Shipping Term:&nbsp</label>
						<?php echo e($order->shippingTerm); ?>

				</div>
				<div class="salesUnitPriceBasisUOM">
					<label>Sales Unit Price Basis (UOM):&nbsp</label>
						<?php echo e($order->salesUnitPriceBasisUOM); ?>

				</div>
				<div class="quantityPerPackageUOM">
					<label>Quantity Per Package (UOM):&nbsp</label>
						<?php echo e($order->quantityPerPackageUOM); ?>

				</div>
				<div class="unitPrice">
					<label>Unit Price:&nbsp</label>
						<?php echo e($order->unitPrice); ?>

				</div>
				<div class="referenceDateETD">
					<label>Reference Date/ETA:&nbsp</label>
						<?php echo e($order->referenceDateETD); ?>

				</div>
				<div class="amount">
					<label>Amount:&nbsp</label>
						<?php echo e($order->amount); ?>

				</div>
			
			</div>


			<div class="rightinfo">

				<div class="orderSubmitted">
					<label>ORDER SUBMITTED:&nbsp</label>
						<?php echo e($order->created_at); ?>

				</div>
				<!-- <div class="IssuedDate">
					<label>Issued Date:</label>
						<?php echo e($order->IssuedDate); ?>

				</div> -->
				<div class="remark">
					<label>Remark:&nbsp</label>
						<?php echo e($order->remark); ?>

				</div>
				<div class="paymentTerm">
					<label>Payment Term:&nbsp</label>
						<?php echo e($order->paymentTerm); ?>

				</div>
				<div class="quantity">
					<label>Quantity:&nbsp</label>
						<?php echo e($order->quantity); ?>

				</div>
				<div class="UOM">
					<label>UOM:&nbsp</label>
						<?php echo e($order->UOM); ?>

				</div>
				<div class="deliveryDateETA">
					<label>Delivery Date/ETA:&nbsp</label>
						<?php echo e($order->deliveryDateETA); ?>

				</div>
				<div class="RONo">
					<label>R/O No:&nbsp</label>
						<?php echo e($order->RONo); ?>

				</div>

				<div class="totalAmount">
					<label><b>Total Amount:&nbsp</b></label>
				</div>


			</div>
        </div>
	

</body>
</html>


<?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/client/myOrderDetailsPage.blade.php ENDPATH**/ ?>