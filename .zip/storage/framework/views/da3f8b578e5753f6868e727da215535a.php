<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/mydesignsliststyle.css" >
    <link rel="stylesheet" href="css/navbarstyle.css" >
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<title>Appointment List</title>
</head>
<body>


<div class="menu-container">
    <div class="menu">
        <div class="logo"><img src="images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

        <div class="links">
            <div class="home">Home</div>
            <div class="appointment_list"><a href="<?php echo e(route('appointment.index')); ?>" style="text-decoration:none; color:black">Appointment List</a></div>
            <div class="order_list"><a href="<?php echo e(route('prod.ordersListPage')); ?>" style="color:black;text-decoration:none">Order List</a></div>
            <div class="design_list"><a href="<?php echo e(route('prod.designsListPage')); ?>" style="text-decoration:none; color:black">Design List</a></div>
        </div>

		<?php if(auth()->guard()->check()): ?>
       
	   <div class="dropdown">
		   <div class="profile-group">
			   <div class="profile-pic"><img  src="images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
			   <div class="profile"><p class="dropbtn"><?php echo e(auth()->user()->name); ?></p></div>
		   </div>

		   <div class="dropdown-content">
			   <a href="#">Account Settings</a>
			   <a href="#">Sign Out</a>
		   </div>


	   </div>

	   <?php endif; ?>
        
    </div>
</div>

	<?php if($message = Session::get('success')): ?>

	<div class="alert alert-success">
		<?php echo e($message); ?>

	</div>

	<?php endif; ?>


	<div class="card">

		<div class="cardheader">
			<div class="row">
				<div class="col col-md-6" id="thetitle"><b>Appointments Details</b></div>
				
				<a href="<?php echo e(route('appointment.index')); ?>" class="btn btn-primary btn-sm float-end">View All</a>
			</div>
			</div>
		</div>

	
		<div class="cardbody">
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form"><b>Company Name</b></label>
                <div class="col-sm-10">
					<?php echo e($appointment->getClient->buyerName); ?>

                </div>
            </div>
			<div class="row mb-3">
                <label class="col-sm-2 col-label-form"><b>Client ID</b></label>
                <div class="col-sm-10">
					<?php echo e($appointment->getClient->buyerCode); ?>

                </div>
            </div>
			<div class="row mb-3">
                <label class="col-sm-2 col-label-form"><b>Contact No.</b></label>
                <div class="col-sm-10">
					<?php echo e($appointment->getClient->contactNum); ?>

                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form"><b>Appointment Purpose</b></label>
                <div class="col-sm-10">
                    <?php echo e($appointment->appPurpose); ?>

                </div>
            </div>
            <div class="row mb-4">
                <label class="col-sm-2 col-label-form"><b>App Date</b></label>
                <div class="col-sm-10">
                    <?php echo e($appointment->appDate); ?>

                </div>
            </div>
            <div class="row mb-4">
                <label class="col-sm-2 col-label-form"><b>Email</b></label>
                <div class="col-sm-10">
                    <?php echo e($appointment->getClient->email); ?>

                </div>
            </div>
            <div class="row mb-4">
                <label class="col-sm-2 col-label-form"><b>Appointment Time</b></label>
                <div class="col-sm-10">
                    <?php echo e($appointment->appTime); ?>

                </div>
            </div>

			<div class="row mb-4">
			<form method="post" action="<?php echo e(route('appointment.update', $appointment->appID)); ?>" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				
				<input type="hidden" name="hidden_id" value="<?php echo e($appointment->appID); ?>" />
				<input name="appStatus" type="submit" class="btn btn-success" value="Accepted" />
				<input name="appStatus" type="submit" class="btn btn-danger" value="Rejected" />
			</form>
            </div>


			
        </div>

	</div>

</body>
</html>



<?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/prod/appointmentDetailsPage.blade.php ENDPATH**/ ?>