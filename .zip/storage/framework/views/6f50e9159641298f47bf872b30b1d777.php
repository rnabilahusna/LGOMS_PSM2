<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/mydesignsliststyle.css" >
    <link rel="stylesheet" href="css/navbarstyle.css" >
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<title>My Designs List</title>
</head>
<body>
	<div class="menu-container">
		<div class="menu">
			<div class="logo"><img src="images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

			<div class="links">
				<div class="home">Home</div>
				<div class="my_designs">My Designs</div>
				<div class="my_orders">My Orders</div>
			</div>

			<div class="dropdown">
				<div class="profile-group">
					<div class="profile-pic"><img  src="images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
					<div class="profile"><p class="dropbtn">Profile</p></div>
				</div>

				<div class="dropdown-content">
					<a href="#">Account Settings</a>
					<a href="#">Sign Out</a>
				</div>
			</div>
			
		</div>
	</div>

	<?php if($message = Session::get('success')): ?>

	<div class="alert alert-success">
		<?php echo e($message); ?>

	</div>

	<?php endif; ?>

	<div class="card">
		<div class="cardheader">
			<div class="row">
				<div class="col col-md-6" id="thetitle"><b>My Design</b></div>
			</div>
		</div>

	

		<div class="cardbody">
		
            <div class="right-content"></div>
            <div class="left-content"></div>
		</div>


		
	</div>

</body>
</html>


<?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/myDesignConfirmationPage.blade.php ENDPATH**/ ?>