

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Signup Staff</title>
    <link rel="stylesheet" href="css/navbarstyle.css" >
    <link rel="stylesheet" href="css/signupstyle.css" >
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"> -->
</head>
<body>
<div class="menu-container">
    <div class="menu">
        <div class="logo"><img src="/images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

        <div class="links">
        <div class="home"><a href="<?php echo e(route('sales.mainWindow')); ?>" style="color:black; text-decoration:none">Home</a></div>
            <div class="register_user">Register User</div>
            <div class="order_list"><a href="<?php echo e(route('sales.ordersListPage')); ?>" style="color:black; text-decoration:none">Order List</div>
            <div class="design_list"><a href="<?php echo e(route('sales.designsListPage')); ?>" style="color:black; text-decoration:none">Design List</a></div>
        </div>

		<?php if(auth()->guard()->check()): ?>
       
		<div class="dropdown">
			<div class="profile-group">
				<div class="profile-pic"><img  src="/images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
				<div class="profile"><p class="dropbtn"><?php echo e(auth()->user()->name); ?></p></div>
			</div>

			<div class="dropdown-content">
				<a href="logout">Sign Out</a>
			</div>


		</div>

		<?php endif; ?>
        
    </div>
</div>

<?php if($message = Session::get('success')): ?>

<div class="alert alert-success">
    <?php echo e($message); ?>

</div>

<?php endif; ?>

<div class="smaller_body">
    <div class="bg">
        <img src="images/bg_1.jpg" alt="">
    </div>
</div>

<div class="container-contents-right">

                <div class="btnrole">
                            <button type="submit" class="btnstaff" onclick="#">Staff</button>
                            <button type="submit" class="btnclient"><a href="<?php echo e(route('register.signUpPageClient')); ?>" style="color:white; text-decoration:none">Client</a></button>
                </div>

                <p style="color: grey;font-size:20px;text-align:center;padding-top: 20px;">Sign up for Staff</p>
                
              <form id="registerFormP" class="well form-horizontal" action="/register" method="post">
                <?php echo csrf_field(); ?>
                <div class="contents-right">
                  <div class="PI-left">
                      <p style="text-decoration:underline;color: grey;">Personal Information</p>



                        <div class="form-group">
                            <div class="col-md-4 inputGroupContainer">
                                <div class="input-group">
                                    <span class="input-group-addon"></span>
                                    <input  name="name" placeholder="Full Name *" class="form-control"  type="text" Required value="<?php echo e(old('name')); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger" style="color:red"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-4 inputGroupContainer">
                                <div class="input-group">
                                    <span class="input-group-addon"></span>
                                    <input  name="ICNo" placeholder="IC Number *" class="form-control"  type="text" Required value="<?php echo e(old('ICNo')); ?>"> 
                                    <?php if($errors->has('ICNo')): ?>
                                            <span class="text-danger" style="color:red"><?php echo e($errors->first('ICNo')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Citizenship&emsp;</label>
                                    <label>
                                        <input type="radio" name="citizenship" value="malaysian" /> Malaysian
                                    </label>
                                    <label>
                                        <input type="radio" name="citizenship" value="non-malaysian" /> Non-Malaysia
                                    </label>
                      </div>


                      <div class="form-group">
                            <div class="col-md-4 inputGroupContainer">
                                <div class="input-group">
                                    <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" name="contactNum" placeholder="012-34567890" required value="<?php echo e(old('contactNum')); ?>">
                                        <?php if($errors->has('contactNum')): ?>
                                            <span class="text-danger" style="color:red"><?php echo e($errors->first('contactNum')); ?></span>
                                        <?php endif; ?>
                                    </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-md-4 inputGroupContainer">
                                <div class="input-group">
                                    <span class="input-group-addon"></span>
                                    <input  name="staffID" placeholder="Staff ID *" class="form-control"  type="text" Required value="<?php echo e(old('staffID')); ?>">
                                    <?php if($errors->has('staffID')): ?>
                                            <span class="text-danger" style="color:red"><?php echo e($errors->first('staffID')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>


                      <div class="dept">
                            <label for="department" class="form-group">Department</label>
                            <select name="department" class="form-group" style="width:85%; height:40px; color:grey; padding-left: 10px">
                                   
                                                <option name="department" value="Sales"> Sales department</option>
                                        
                                                <option name="department" value="Store"> Store department</option>
                                            
                                                <option name="department" value="QC"> Quality Control department</option>
                                        
                                                <option name="department" value="Production">  Production department</option>
                                        
                            </select>
                        </div>

                        <div class="role">
                            <label for="role" class="form-group">Role</label>
                            <select name="role" class="form-group" style="width:85%; height:40px; color:grey; padding-left: 10px">
                                   
                                                <option name="role" value="Sales"> Sales personnel</option>
                                        
                                                <option name="role" value="Store"> Store personnel</option>
                                            
                                                <option name="role" value="QC"> Quality Control personnel</option>
                                        
                                                <option name="role" value="Production">  Production personnel</option>
                                        
                            </select>
                        </div>


                  </div>

                  <div class="PI-right">
                  
                  <p style="text-decoration:underline;color: grey;"> Login Info </p>

                        
                  
                        <div class="form-group">
                                <div class="col-md-4 inputGroupContainer">
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input  name="email" placeholder="Email *" class="form-control"  type="text" Required value="<?php echo e(old('email')); ?>">
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger" style="color:red"><?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>


                        <div class="form-group">
                                <div class="col-md-4 inputGroupContainer">
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input  id="password" name="password" placeholder="Password *" class="form-control"  type="password" Required value="<?php echo e(old('password')); ?>">
                                        <?php if($errors->has('password')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                        <?php endif; ?>
                                        <span id="message" style="color:red"> </span> <br>
                                    </div>
                                </div>
                            </div>

                        <!-- <input  id="role" name="role" value="staff" type="hidden"> -->
                        <button type="submit" id="registerbutton" class="button buttonregister" >Register</button>
                             

                        </div>
                    </div>
                </div>

                
            </form>
        </div>


</body>
</html>

<?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/register/index.blade.php ENDPATH**/ ?>