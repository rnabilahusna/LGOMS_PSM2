<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <link rel="stylesheet" href="css/mydesignsliststyle.css" >
    <link rel="stylesheet" href="css/navbarstyle.css" >
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
</head>
<body>

<div class="menu-container">
    <div class="menu">
        <div class="logo"><img src="images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

        <div class="links">
            <div class="home">Home</div>
            <div class="order_list">Order List</div>
            <div class="design_list">Design List</div>
        </div>


        <?php if(auth()->guard()->check()): ?>
       
        <div class="dropdown">
            <div class="profile-group">
                <div class="profile-pic"><img  src="images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
                <div class="profile"><p class="dropbtn"><?php echo e(auth()->user()->name); ?></p></div>
            </div>

            <div class="dropdown-content">
                <a href="#">Account Settings</a>
                <a href="#">Sign Out</a>
            </div>


        </div>

        <?php endif; ?>
        
    </div>
</div>

<?php if($message = Session::get('success')): ?>

	<div class="alert alert-success">
		<?php echo e($message); ?>

	</div>

	<?php endif; ?>

<div class="card">
		<div class="cardheader">
			<div class="row">
				<div class="col col-md-6" id="thetitle"><b>Designs List</b></div>
				<div class="col col-md-6">
					<a href="<?php echo e(route('appointment.appointmentForm')); ?>'" class="btn btn-success btn-sm float-end" id="requestbutton" >Request New Design</a>
				</div>
			</div>
		</div>

	

		<div class="cardbody">
		<table class="table table-bordered" style="width:100%">
			<tr>
				<th width="15%">Part No. & Name</th>
				<th width="20%">Client Name</th>
				<th width="30%">Part Design</th>
				<th width="15%">Creation Date</th>
				<th width="12%"></th>
			</tr>
			
			<?php if(count($data) > 0): ?>

				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						
						<td><?php echo e($row->partNo); ?></td>
						<td><?php echo e($row->getClient->buyerName); ?></td>
						<td><img src="<?php echo e(asset('images/' . $row->partDesign)); ?>" width="75" /></td>
						<td><?php echo e($row->created_at); ?></td>
						<td>

                        <form method="post" action="<?php echo e(route('design.destroy', $row->designID)); ?>">
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>
								<a style="text-decoration:none" class="viewbutton" href="<?php echo e(route('design.show', $row->designID)); ?>" class="btn btn-primary btn-sm">View</a>
								<a href="<?php echo e(route('design.edit', $row->designID)); ?>" class="btn btn-warning btn-sm">Edit</a>
								<input type="submit" class="btn btn-danger btn-sm" value="Delete" />
							</form>

                        </td>
					</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php else: ?>
				<tr>
					<td colspan="5" class="text-center">No Data Found</td>
				</tr>
				<?php endif; ?>

		</table>
		<?php echo $data->links(); ?>


		</div>


		
	</div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/designsListPage_store.blade.php ENDPATH**/ ?>