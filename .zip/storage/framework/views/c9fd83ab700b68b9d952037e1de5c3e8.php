<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/mydesignsliststyle.css" >
    <link rel="stylesheet" href="css/navbarstyle.css" >
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<title>My Orders List</title>
</head>
<body>
		<div class="menu-container">
		<div class="menu">
			<div class="logo"><img src="images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

			<div class="links">
				<div class="home">Home</div>
				<div class="my_designs">My Designs</div>
				<div class="my_orders">My Orders</div>
			</div>

			<div class="dropdown">
				<div class="profile-group">
					<div class="profile-pic"><img  src="images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
					<div class="profile"><p class="dropbtn">Profile</p></div>
				</div>

				<div class="dropdown-content">
					<a href="#">Account Settings</a>
					<a href="#">Sign Out</a>
				</div>
			</div>
			
		</div>
	</div>

	<?php if($message = Session::get('success')): ?>

	<div class="alert alert-success">
		<?php echo e($message); ?>

	</div>

	<?php endif; ?>

	<div class="card">
		<div class="cardheader">
			<div class="row">
				<div class="col col-md-6" id="thetitle"><b>My Orders List</b></div>
			</div>
		</div>

	

		<div class="cardbody">
		<table class="table table-bordered" style="width:100%">
			<tr>
				<th width="5%">Order ID</th>
				<th width="10%">Part No & Name</th>
				<th width="10%">Status</th>
				<th width="10%">Updated</th>
                <th width="9%">Payment Status</th>
                <th width="6%"></th>
			</tr>
			
			<?php if(count($data) > 0): ?>

				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<td><?php echo e($row->PONo); ?></td>
						<td><?php echo e($row->partNo); ?> / <?php echo e($row->partDescription); ?></td>
                        <td><?php echo e($row->orderStatus); ?></td>
                        <td><?php echo e($row->updated_at); ?></td>
						<td><?php echo e($row->paymentStatus); ?></td>
						<td><button class="viewbutton">View order</button></td>
					</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php else: ?>
				<tr>
					<td colspan="5" class="text-center">No Data Found</td>
				</tr>
				<?php endif; ?>

		</table>
		<?php echo $data->links(); ?>


		</div>


		
	</div>

</body>
</html>


<?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/myOrdersListPage.blade.php ENDPATH**/ ?>