<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>hello <?php echo e($name); ?></h1>
    <h1><?php echo e($email); ?></h1>
    <h1><?php echo e($password); ?></h1>
</body>
</html> -->

<?php $__env->startComponent('mail::message'); ?>

Dear <?php echo e($name); ?>,

Your account credentials are as follows:

Email: <?php echo e($email); ?>

Password: <?php echo e($password); ?>



<?php $__env->startComponent('mail::button', ['url' => 'https://www.google.com/']); ?>
Click here to login
<?php echo $__env->renderComponent(); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/emails/welcome.blade.php ENDPATH**/ ?>