<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/mydesignsliststyle.css" >
    <link rel="stylesheet" href="css/navbarstyle.css" >
    <link rel="stylesheet" href="css/clientDashboard.css" >
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<title>Dashboard</title>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
	<div class="menu-container">
		<div class="menu">
			<div class="logo"><img src="images/Lengkuas_Logo_1.svg" alt="LG Logo" style="width:180px;height:45px;"></div>

			<div class="links">
            <div class="home">Home</div>
				<div class="my_designs"><a href="<?php echo e(route('client.myDesignsListPage')); ?>" style="color:black; text-decoration:none">My Designs</div>
				<div class="my_orders"><a href="<?php echo e(route('client.myOrdersListPage')); ?>" style="color:black; text-decoration:none">My Orders</a></div>
			</div>

			<?php if(auth()->guard()->check()): ?>
       
			<div class="dropdown">
				<div class="profile-group">
					<div class="profile-pic"><img  src="images/profile_picture_default.png" alt="profile pic" style="width:45px;height:45px;"></div>
					<div class="profile"><p class="dropbtn"><?php echo e(auth()->user()->name); ?></p></div>
				</div>

				<div class="dropdown-content">
					<a href="logout">Sign Out</a>
				</div>


			</div>

			
			
		</div>
	</div>

<?php if($message = Session::get('success')): ?>

<div class="alert alert-success">
    <?php echo e($message); ?>

</div>

<?php endif; ?>


<div class="card">
    <div class="cardheader">
        <div class="row">
            <div class="col col-md-6" id="thetitle">
                <b>Welcome back, <?php echo e(auth()->user()->name); ?></b>
            </div>
        </div>
    </div>

    <div class="cardbody card-body" >

				<?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<div class="alert alert-success" role="alert" >
					
                    <?php if($notification->type === 'App\Notifications\NewQuotationUpdateNotification'): ?>
                        Your quotation for design part 
						<?php if($notification->data['designConfirmationStatus'] == 'ACCEPTED'): ?>
						<a href="<?php echo e(route('design.showForClient', $notification->data['designID'])); ?>" data-id="<?php echo e($notification->id); ?>">
						<b><?php echo e($notification->data['partNo']); ?></b> <b><?php echo e($notification->data['partDescription']); ?></b> 
						</a>
						has been <b><?php echo e($notification->data['designConfirmationStatus']); ?></b>.
						<?php else: ?>
						<b><?php echo e($notification->data['partNo']); ?></b> <b><?php echo e($notification->data['partDescription']); ?></b> 
						has been <b><?php echo e($notification->data['designConfirmationStatus']); ?></b>.
						<?php endif; ?>
					
					<?php elseif($notification->type === 'App\Notifications\NewPaymentUpdateNotification'): ?>
                        Your order 
						<a href="<?php echo e(route('order.showForClient', $notification->data['id'])); ?>" data-id="<?php echo e($notification->id); ?>">
						<b><?php echo e($notification->data['PONo']); ?></b>
						</a>
						payment proof for <b><?php echo e($notification->data['partDescription']); ?></b> has been <b><?php echo e($notification->data['paymentStatus']); ?></b>.
                    
					<?php endif; ?>


						<a href="#" class="float-end mark-as-read" data-id="<?php echo e($notification->id); ?>">
							Mark as read
						</a>
					</div>

					<?php if($loop->last): ?>
						<a href="#" id="mark-all mark-as-read">Mark all as read</a>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						
						<div class="theImages">
							<div class="leftimage">
								<a href="<?php echo e(route('client.myDesignsListPage')); ?>">
									<img class="theimage" src="images/clientDashboard1.png" alt="The design list" style="width:25em;height:25em;">
									<a class="viewbutton" href="">View design</a>
								</a>
							</div>
							
							<div class="rightimage">
								<a href="<?php echo e(route('client.myOrdersListPage')); ?>">
									<img class="theimage" src="images/clientDashboard2.png" alt="The order list" style="width:25em;height:25em;">
									<a class="viewbutton" href="">View order</a>
								</a>
							</div>
						</div>
				<?php endif; ?>


    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script type="text/javascript">
        var _token = "<?php echo e(csrf_token()); ?>"; // Add this line to define the _token variable
        function sendMarkRequest(id = null) {
            return $.ajax("<?php echo e(route('markNotification')); ?>", {
                method: 'POST',
                data: {
                    _token,
                    id
                }
            });
        }
        $(function() {
            $('.mark-as-read').click(function() {
                let request = sendMarkRequest($(this).data('id'));
                request.done(() => {
                    $(this).parents('div.alert').remove();
                });
            });
            $('#mark-all').click(function() {
                let request = sendMarkRequest();
                request.done(() => {
                    $('div.alert').remove();
                })
            });
        });
    </script>

	</script>
	</script>

     <?php endif; ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\LGOMS_NABILA\LGOMS_PSM2\resources\views/client/mainWindow.blade.php ENDPATH**/ ?>